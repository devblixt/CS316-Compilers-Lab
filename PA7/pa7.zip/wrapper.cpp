#include <string>
#include "makers.hpp"
std::string ASTNode::id_type;